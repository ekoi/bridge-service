#!/bin/bash
echo "Starting dataverse bridge Quickstart...."
nohup java -Dspring.profiles.active=dev -jar target/bridge-service-0.5.0.jar >> /dev/null &
echo "Wait..."
sleep 5
echo "Wait..."
sleep 5
echo "Wait 11 seconds..."
sleep 11
echo "Now, you can open your favourite browser and visit the bridge API: http://localhost:8592/api"
